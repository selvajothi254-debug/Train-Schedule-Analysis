# Train Schedule Analysis & Enquiry System

## Internship Project

This project analyzes train schedule data and provides an interactive train enquiry workflow.

### Objective
- Explore and understand train schedule data.
- Clean and validate the dataset.
- Analyze routes, stations, and journey durations.
- Create useful visualizations and summary tables.
- Provide an interactive way to check trains between selected stations.

### Technologies Used
- Python
- Pandas
- Matplotlib
- Jupyter Notebook

### Project Contents
- `Train_Schedule_Analysis.ipynb` — complete analysis and interactive enquiry workflow.
- `Dataset1.csv` — original dataset.
- `Level3_Verified_Dataset.csv` — verified/processed dataset.
- `Project_Report.pdf` — internship project report.

### Notebook Workflow
1. Data loading and exploration
2. Data cleaning and preprocessing
3. Data-quality verification
4. Exploratory analysis
5. Visualizations
6. Pivot/cross-tab analysis
7. Train enquiry and journey-duration functionality

### How to Run
1. Install Python and Jupyter Notebook.
2. Install required packages:
   `pip install pandas matplotlib`
3. Open `Train_Schedule_Analysis.ipynb` in Jupyter.
4. Keep the CSV files in the same project directory.
5. Run the notebook cells from top to bottom.

### Note on Train Enquiry
The enquiry workflow identifies trains whose route contains the selected source and destination stations. Because a train may stop at intermediate stations, the term "Available Trains" is used rather than implying that every result is a non-stop/direct service.

### Conclusion
The project demonstrates practical skills in data handling, validation, analysis, visualization, and building a simple data-driven enquiry workflow using Python.
